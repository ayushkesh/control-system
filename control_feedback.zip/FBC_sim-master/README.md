# Control-system Feedback-circuit having Positive Feed-back system and have frequency in the range of kHz.
# This can also be scaled in MHz range by small change in the parameter. 
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Ex- By changing value of R= 100 ohm and C= 0.1uF and R_1 = 1k and R_2 = 2030 ohm, we can  get f= 0.015 MHz.


